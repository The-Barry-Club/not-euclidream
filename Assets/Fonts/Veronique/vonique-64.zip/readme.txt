TrueTypeFont: Vonique 64
Dennis Ludlow 2015 all rights reserved
Sharkshock Productions
dennis@sharkshock.net

Hey Everybody. Meet Vonique 64. My inspiration came from walking around New York's 5th Ave., the Champs-�lys�es in Paris,and Oxford Street in London. Think black and white perfume ads behind
glass. The smell of roasted beans trickling out of that upscale coffee shop. The ornate lamp post. You've got the idea! Vonique 64 is sophisticated, urban, and curvy but tries not to take itself
too seriously. This font family comes in 4 different weights: regular, italic, bold, and bold italic. Feel free to redistribute as long as this readme file stays intact. This font is free for
 personal use only. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license. I also design custom fonts for businesses, logos, and many other things. 

visit www.sharkshock.net for more and take a bite out of BORING design!

